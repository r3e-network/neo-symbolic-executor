"""Report module."""
from .generator import ReportGenerator
